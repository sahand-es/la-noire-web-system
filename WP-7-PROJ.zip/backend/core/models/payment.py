from django.db import models
from .base import BaseModel


class Payment(BaseModel):
    pass


class Bail(BaseModel):
    pass

